import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

import Graph.BreadthFirstPaths;
import Graph.DepthFirstPaths;
import Graph.Graph;
import Graph.GraphAPI;
import Graph.ReadText;
import Graph.Search;


public class GraphTest {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

//		BufferedReader in=new BufferedReader(new FileReader("/home/here/Downloads/test/graph.txt"));
//		int str;
//		while((str=in.read())!=-1){
//			if(str!=10&&str!=32)
//			System.out.println((char)str);	
//		}
//		ReadText r=new ReadText("/home/here/Downloads/test/graph.txt");
//		char[] chars=r.ReadFromText("/home/here/Downloads/test/graph.txt");
//		System.out.println(r.next());
//		System.out.println(r.next());
		
		Graph graph=new Graph("/home/here/Downloads/test/graph.txt");
		System.out.println("V:"+graph.V()+" E:"+graph.E());
		GraphAPI gapi=new GraphAPI(graph);
		System.out.println(gapi.degree(2));
		System.out.println(gapi.maxDegree());
		System.out.println(gapi.toString());
		
		Search search=new Search(graph,1);
		System.out.println(search.count());
		
		DepthFirstPaths depthSearch=new DepthFirstPaths(graph,0);
		for(int v=0;v<graph.V();v++){
			System.out.print("0 to "+v+" :");
			if(depthSearch.hasPathTo(v))
				for(int x:depthSearch.pathTo(v))
				{
					if(x==0) System.out.print("0");
					else System.out.print(x+"-");
				}
			System.out.println();
		}
		
		BreadthFirstPaths breadthSearch=new BreadthFirstPaths(graph,0);
		for(int v=0;v<graph.V();v++){
			System.out.print("0 to "+v+" :");
			if(breadthSearch.hasPathTo(v))
				for(int x:breadthSearch.pathTo(v))
				{
					if(x==0) System.out.print("0");
					else System.out.print(x+"-");
				}
			System.out.println();
		}
	}
		

}
