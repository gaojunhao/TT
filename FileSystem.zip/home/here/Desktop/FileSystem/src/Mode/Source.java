package Mode;

public interface Source {
public void method1();
public void method2();
}
