package Mode;

public class SourceMethod implements Source{

	public void method1() {
		// TODO Auto-generated method stub
		System.out.println("method1~~");
	}

	public void method2() {
		// TODO Auto-generated method stub
		System.out.println("method2--");
	}

}
