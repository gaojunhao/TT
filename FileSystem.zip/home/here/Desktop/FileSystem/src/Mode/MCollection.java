package Mode;

public interface MCollection {
public MIterator miterator();
public Object get(int i);
public int size();
}
