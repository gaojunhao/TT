package Mode;

public class Observer2 implements Observer{

	public void update() {
		// TODO Auto-generated method stub
		System.out.println("Observer2");
	}

}
