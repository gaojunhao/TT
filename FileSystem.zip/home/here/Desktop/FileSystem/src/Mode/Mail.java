package Mode;

public class Mail implements Sender{

	public void send() {
		// TODO Auto-generated method stub
		System.out.println("mail send msg");
	}

}
