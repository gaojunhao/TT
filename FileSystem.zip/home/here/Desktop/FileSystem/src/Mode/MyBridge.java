package Mode;

public class MyBridge extends Bridge{
public void method(){
	get().method1();
	get().method2();
}
}
