package Mode;

public class Sms implements Sender{

	public void send() {
		// TODO Auto-generated method stub
		System.out.println("Sms send msg");
	}

}
