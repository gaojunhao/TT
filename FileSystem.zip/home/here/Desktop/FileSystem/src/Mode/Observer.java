package Mode;

public interface Observer {
public void update();
}
