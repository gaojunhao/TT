package Mode;

public class MySubject extends SubjectDetail{

	public void operation() {
		// TODO Auto-generated method stub
		System.out.println("operation");
		notifyAllServer();
	}

}
