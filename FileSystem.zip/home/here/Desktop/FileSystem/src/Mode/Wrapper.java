package Mode;

public abstract class Wrapper implements Source{
public void method1(){}
public void method2(){}
}
