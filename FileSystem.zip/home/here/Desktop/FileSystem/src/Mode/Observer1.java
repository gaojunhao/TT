package Mode;

public class Observer1 implements Observer{

	public void update() {
		// TODO Auto-generated method stub
		System.out.println("Observer1");
	}

}
