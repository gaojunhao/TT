package Mode;

public interface Sender {
public void send();
}
