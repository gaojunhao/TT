package Mode;

public interface provider {
public Sender produce();
}
