package Mode;

public interface MIterator {
public boolean hasNext();
public Object next();
}
