package Mode;

public abstract class AClass {
public abstract void work();
public void desk(){}
}
