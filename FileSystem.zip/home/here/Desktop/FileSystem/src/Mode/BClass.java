package Mode;

public class BClass extends AClass{

	@Override
	public void work() {
		// TODO Auto-generated method stub
		
	}

}
