package Mode;

public class SourceSub1 extends Wrapper{
public void method1(){
	System.out.println("method1");
}
}
