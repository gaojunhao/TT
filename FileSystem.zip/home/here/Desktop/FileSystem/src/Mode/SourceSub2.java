package Mode;

public class SourceSub2 extends Wrapper{
public void method2(){
	System.out.println("method2");
}
}
