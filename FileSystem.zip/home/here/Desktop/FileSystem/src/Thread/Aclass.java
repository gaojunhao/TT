package Thread;

public class Aclass {
public static Ainterface newA(){
	return new Ainclass();
}
}
