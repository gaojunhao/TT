package Thread;

public class UnderTest {
public void before(){
	System.out.println("UnderTest before");
}
public void after(){
	System.out.println("UnderTest after");
}
}
