package Thread;

public interface B {
public abstract void run();
}
