package Thread;

public class Resource {

}
