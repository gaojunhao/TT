package Thread;

public abstract class AabstactClass implements Ainterface{

}
