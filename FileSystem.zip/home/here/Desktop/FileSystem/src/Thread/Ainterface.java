package Thread;

public interface Ainterface extends A{

}
