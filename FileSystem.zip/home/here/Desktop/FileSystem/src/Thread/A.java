package Thread;

public interface A {
void execute(B b);
}
