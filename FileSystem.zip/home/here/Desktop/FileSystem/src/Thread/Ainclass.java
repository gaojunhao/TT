package Thread;

public class Ainclass extends AabstactClass{

	public void execute(B b) {
		// TODO Auto-generated method stub
        b.run();		
	}

}
