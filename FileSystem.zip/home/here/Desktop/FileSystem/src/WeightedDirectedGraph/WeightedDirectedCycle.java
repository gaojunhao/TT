package WeightedDirectedGraph;

import java.util.Stack;

public class WeightedDirectedCycle {
	private boolean[] marked;
	private int[] edgeTo;
	private Stack<Integer> cycle;
	private boolean[] onStack;
	public WeightedDirectedCycle(EdgeWeightedDigraph EWD){
		marked=new boolean[EWD.V()];
		edgeTo=new int[EWD.V()];
		onStack=new boolean[EWD.V()];
		for(int v=0;v<EWD.V();v++){
			if(!marked[v]) dfs(EWD,v);
		}
	}
	public void dfs(EdgeWeightedDigraph EWD,int v){
		marked[v]=true;
		onStack[v]=true;
		for(DirectedEdge e:EWD.adj(v)){
			int w=e.to();
			if(this.hasCycle()) return;
			else if(!marked[w]){
				edgeTo[w]=v;
				dfs(EWD,w);
			}else if(onStack[w]){
				cycle=new Stack<Integer>();
				for(int x=v;x!=w;x=edgeTo[x]){
					cycle.push(x);
				}
				cycle.push(w);
				cycle.push(v);
			}
		}
		onStack[v]=false;
	}
	public boolean hasCycle(){
		return cycle!=null;
	}
	public Stack<Integer> cycle(){
		return cycle;
	}
}
