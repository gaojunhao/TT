


public class B extends A{
	int x=100;
	public B(int x){
		super(x);
//		this.x = x ;
//		this.print();
	}
	public void print(){
		System.out.println("x = " + x) ;
		}
}
