
public class ThingObject {
	public String Name;
//	public int flag;
public ThingObject(String name){
	Name=name;
}
//public void test(){
//	if(flag==0){
//		
//	}
//}
}
