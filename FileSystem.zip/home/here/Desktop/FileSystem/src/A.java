
public class A {
	int x=50;
	public A(int i){
		this.x=i;
		this.print() ;
	}
	public void print(){
		System.out.println("x = " + x) ;
		}
}
